<?php

require_once('../../class/userPost/feedback.php');
$feedback = new Feedback();
$query_result = $feedback->all_clientFeedback_info();

// Delete feedback if delete request is received
if (isset($_GET['delete_id'])) {
    $feedback_id = $_GET['delete_id'];
    $feedback->delete_clientFeedback_info($feedback_id);
    header('Location: report_issue.php'); // Redirect to avoid re-deletion on refresh
}

session_start();
if ($_SESSION['user_id'] == null) {
    header('Location: ../login.php');
}

if (isset($_GET['logout'])) {
    require_once('../../class/userLogin/login.php');
    $obj_login = new Login();
    $obj_login->user_logout();
}

require_once('../../class/userPost/userpost.php');
$obj_userPost = new Userpost();
/*this code for user post in footer*/
$user_post_result = $obj_userPost->all_userPost_info_for_footer();

/*this code for user post picture in footer*/
$user_post_picture = $obj_userPost->all_userPost_picture_for_footer();

/*this code for contact us Address in main content*/
$contact_address = $obj_userPost->all_contact_address_info();
$all_contact_address = mysqli_fetch_assoc($contact_address);

/*this code for contact us Social Address in main content*/
$social_address = $obj_userPost->all_social_address_info();
$all_social_address = mysqli_fetch_assoc($social_address);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Power Vehicles | Issues</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">

    <!-- External CSS libraries -->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="../css/font-awesome-4.5.0/css/font-awesome.min.css">

    <!-- Custom stylesheet -->
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <!-- Fafa icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700|Oleo+Script:400,700" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="mainSite/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body>
    <header class="top-header hidden-xs">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <ul class="list-inline">
                        <li>
                            <a href="tel:03324545112"><i class="fa fa-phone pr-5 pl-10"></i> 03324545112</a>
                        </li>
                        <li>
                            <a href="mailto:info@ptechagency.com">
                                <i class="fa fa-envelope-o pr-5 pl-10"></i>info@ptechagency.com
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="top-buttons">
                        <a href="?logout=logout" class="btn btn-grey btn-sm text-uppercase"><i class="fa fa-user pr-10"></i>Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </header>


    <!-- Top header end -->

    <!-- Main header start-->
    <div class="main-header">
        <div class="container">
            <nav class="navbar navbar-default">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand-logo" href="../../index.php">
                        <img src="../img/png/mainlogo.png" alt="CAR HOUSE">
                    </a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="userDashboard.php" class="active">Home</a></li>
                        <li><a href="add_post.php">Add Post</a></li>
                        <li><a href="report_issue.php">Issues Reported</a></li>
                        <li><a href="customer_contacts.php">CUSTOMER CONTACT</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->
                <!-- /.container -->
            </nav>
        </div>
    </div>
    <!-- Main header end-->

    <!-- Footer start-->

    <!-- Feedback table start -->
    <div class="container pt-5 pb-5 report_issue">
    <h2>Client Feedback</h2>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Vehicle Make/Model</th>
                    <th>Issue Type</th>
                    <th>Issue Description</th>
                    <th>Vehicle Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Check if there are any records returned
                if (mysqli_num_rows($query_result) > 0) {
                    while ($row = mysqli_fetch_assoc($query_result)) {
                ?>
                        <tr>
                            <td><?php echo $row['vehicle_make_model']; ?></td>
                            <td><?php echo $row['issue_type']; ?></td>
                            <td><?php echo $row['issue_description']; ?></td>
                            <td><img src="<?php echo $row['vehicle_image']; ?>" alt="Vehicle Image" class="img-fluid" style="max-width: 100px;"></td>
                            <td>
                                <a href="<?php echo $row['vehicle_image']; ?>" download class="btn btn-success btn-sm"><i class="fa fa-download"></i> Download</a>
                                <a href="?delete_id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Delete</a>
                            </td>
                        </tr>
                <?php
                    }
                } else {
                    echo "<tr><td colspan='5'>No completed repair issues found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>


    <!-- Feedback table end -->


 <!-- Footer start-->
 <footer class="main-footer">
    <div class="container">
        <div class="footer-row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <div class="footer-item-content">
                    <a href="index.php">
                        <img src="../img/png/mainlogo.png" alt="logo" style="width: 100%; height: 100%;">
                    </a>

                    <br><br>
                </div>
            </div>

            <div class="col-lg-3 col-md=3 col-sm-6 col-xs-12 footer-item">
                <div class="footer-item-content">
                    <h2>Quick Links</h2>
                    <div class="line-dec"></div>
                    <ul>
                        <li>
                            <a href="#">Home</a>
                        </li>
                        <li>
                            <a href="#">Buy Car</a>
                        </li>
                        <li>
                            <a href="#">Our Services</a>
                        </li>
                        <li>
                            <a href="#">Repair Car</a>
                        </li>
                        <li>
                            <a href="#">Contact Us</a>
                        </li>
                        
                    </ul>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 footer-item">
                <div class="footer-item-content">
                    <h2>Contact us</h2>
                    <div class="line-dec"></div>

                    <ul>
                        <li>
                            <a href="#" style="pointer-events: none;">
                                <i class="fa fa-map-marker"></i>
                                K-1 Phase 3 Hayatabad, Peshawar, Khyber Pakhtunkhwa, Pakistan
                            </a>
                        </li>
                        <li>
                            <a href="tel:03324545112">
                                <i class="fa fa-phone"></i> 03324545112
                            </a>
                        </li>
                        <li>
                            <a href="mailto:info@ptechagency.com">
                                <i class="fa fa-envelope-o"></i> info@ptechagency.com
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Add an empty column for spacing -->
            
        </div>
    </div>
</footer>


    <!-- Footer end-->

    <!-- Sub footer start-->
    <div class="sub-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <p>&copy; <?php echo date('Y') ?> All Right Reserved By Power Vehicles </p>
                </div>
                <div class="col-md-6 col-sm-6 hidden-xs ">
                    <ul>
                        <li>
                        <a href="#" class="icon"><i class="fab fa-facebook-f"></i></a>
                        </li>
                        <li>
                        <a href="#" class="icon"><i class="fab fa-twitter"></i></a>
                        </li>
                        <li>
                        <a href="#" class="icon"><i class="fab fa-instagram"></i></a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- Sub footer end-->

    <script src="../js/jquery-2.2.0.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/bootstrap-slider.js"></script>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../js/ie10-viewport-bug-workaround.js"></script>
    <!-- Custom javascript -->
    <script src="../js/app.js"></script>

    <script>
        function downloadImage(url) {
            var link = document.createElement("a");
            link.href = url;
            link.download = "image.jpg";
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>



</body>

</html>
