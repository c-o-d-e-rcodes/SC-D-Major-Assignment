<?php
// 
require_once('database.php');

class Feedback extends Database {

    public function save_image_info() {
        $target_dir = "../../assets/client_feedback_image/";
        $target_file = $target_dir . basename($_FILES["vehicle_image"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
        // Check if image file is an actual image or fake image
        $check = getimagesize($_FILES["vehicle_image"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["vehicle_image"]["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        } else {
            // Ensure the directory exists
            if (!is_dir($target_dir)) {
                if (!mkdir($target_dir, 0777, true)) {
                    die("Failed to create directories...");
                }
            }
            if (move_uploaded_file($_FILES["vehicle_image"]["tmp_name"], $target_file)) {
                return "assets/client_feedback_image/" . basename($_FILES["vehicle_image"]["name"]);
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    }

    public function save_cliendFeedback_info($data){
        $img_url = $this->save_image_info(); // this line for calling an image function

        $query = "INSERT INTO car_repair_issues (vehicle_make_model, issue_type, issue_description, vehicle_image, repair_status)"
            . "VALUES('$data[vehicle_make_model]', '$data[issue_type]', '$data[issue_description]', '$img_url', '$data[repair_status]')";

        if (mysqli_query($this->db_connect, $query)) {
            $message = "Your Feedback Save Successfully!";
            return $message;
        } else {
            die("Query Problem! " . mysqli_error($this->db_connect));
        }
    }

    public function all_clientFeedback_info(){
        $query = "SELECT * FROM car_repair_issues";
        return mysqli_query($this->db_connect, $query);
    }

    public function delete_clientFeedback_info($feedback_id){
        $query = "DELETE FROM car_repair_issues WHERE id = $feedback_id";
        mysqli_query($this->db_connect, $query);
    }
}
?>
